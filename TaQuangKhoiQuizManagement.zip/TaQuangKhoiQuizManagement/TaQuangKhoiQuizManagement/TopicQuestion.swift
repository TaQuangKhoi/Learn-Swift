//
//  Question.swift
//  TaQuangKhoiQuizManagement
//
//  Created by BVU on 5/29/23.
//

import Foundation

struct TopicQuestion {
    var name: String
    var Answer: Array<String>
    var rightAnswer: Int
}
